
import java.text.DecimalFormat;
import java.util.*;

public class Account {
	Scanner input = new Scanner(System.in);
	DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
	
	public int customerNum, pinNum;
	
	protected double  checkingBalance = 0;
	protected double  savingsBalance = 0;
	
	/*Set the Customer number*/
	public void setCustomerNumber (int customerNumber) {
		this.customerNum = customerNumber;
	}
	
	/*Get the customer number*/
	public int getCustomerNumber () {
		return customerNum;
	}
	
	/*Set the Pin number*/
	public  void setPinNumber (int pinNumber) {
		this.pinNum = pinNumber;
	}
	
	/*Get the Pin  number*/
	public  int getPinNumber() {
		return pinNum;
	}
	
	
	/*Get Checking Account Balance*/
	public double getCheckingBalance() {
		return checkingBalance;
	}
	
	/*Get Savings Account Balance*/
	public double getSavingsBalance() {
		return savingsBalance;
	}
	
	/*Calculate Checking Account withdrawal*/
	public double calcCheckingWithdraw(double amount) {
		checkingBalance -= amount;
		return checkingBalance;
	}
	
	/*Calculate SavingsAccount withdrawal*/
	public double calcSavingsWithdraw(double amount) {
		savingsBalance -= amount;
		return savingsBalance;
	}
	
	/*Calculate SavingsAccount withdrawal*/
	public double calcCheckingDeposit(double amount) {
		checkingBalance += amount;
		return checkingBalance;
	}
	
	/*Calculate SavingsAccount withdrawal*/
	public double calcSavingsDeposit(double amount) {
		savingsBalance += amount;
		return savingsBalance;
	}
	
	/*Customer Checking Account Withdraw input*/
	public void getCheckingWithdrawInput() {
		System.out.println("Checking Account Balance is " + moneyFormat.format(checkingBalance));
		System.out.print("Amount you want to withdraw from Checking Account: ");
		
		double amount = input.nextDouble();
		
		if((checkingBalance - amount) >= 0) {
			calcCheckingWithdraw(amount);
			System.out.println("New Checking Account Balnce: " + moneyFormat.format(checkingBalance));
			}else {
				System.out.println("Balance cannot be negative.\n");
				}
		}
	
	/*Customer Saving Account Withdraw Input*/
	public void getSavingsWithdrawInput() {
		System.out.println("Savings Account Balance is " + moneyFormat.format(savingsBalance));
		System.out.print("Amount you want to withdraw from Savings Account: ");
		
		double amount = input.nextDouble();
		if((savingsBalance - amount) >= 0) {
			calcSavingsWithdraw(amount);
			System.out.println("New Savings  Account Balnce: " + moneyFormat.format(savingsBalance));
			}else {
				System.out.println("Balance cannot be negative.\n");
			}
		}
	
	/*Customer Checking Account Deposit input*/
	public void getCheckingDepositInput() {
		System.out.println("Checking Account Balance: " + moneyFormat.format(checkingBalance));
		System.out.print("Amount you want to deposit from Checking Account: ");
		
		double amount = input.nextDouble();
		if((checkingBalance + amount) >= 0) {
			calcCheckingDeposit(amount);
			System.out.println("New Checking  Account Balnce: " + moneyFormat.format(checkingBalance));
			}else {
				System.out.println("Balance cannot be negative.\n");
			}
	}
	
	/*Customer Savings Account Deposit input*/
	public void getSavingsDepositInput() {
		System.out.print("Savings Account Balance: " + moneyFormat.format(savingsBalance));
		System.out.print("Amount you want to deposit from Savings Account: ");
		
		double amount = input.nextDouble();
		if((checkingBalance + amount) >= 0) {
			calcSavingsDeposit(amount);
			System.out.println("New Savings Account Balnce: " + moneyFormat.format(savingsBalance));
			}else {
				System.out.println("Balance cannot be negative.\n");
			}
	}
}

