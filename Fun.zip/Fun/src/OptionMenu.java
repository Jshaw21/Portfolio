/*Main Class*/
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import java.text.DecimalFormat;

public class OptionMenu extends Account{
	// TODO Auto-generated method stub
	Scanner menuInput = new Scanner(System.in);
	Scanner userChoiceInput = new Scanner(System.in);
	Scanner cutomerNewOld = new Scanner(System.in);
	
	DecimalFormat moneyFormat = new DecimalFormat("'$'###,##0.00");
	
	HashMap<Integer, Integer> data = new HashMap <Integer, Integer>();
	
	protected int selection;
	protected String user = "";
	protected String customer;
	
	/*Validate Login Information customer number and pin number*/
	/*Lets user create account, sends it to a file*/
	public void getLogin() throws IOException{
		int x = 1;
		do {
			try {
				data.put(9876543, 9876);
				
				//Intro message
				System.out.println("************************************\n*");
				System.out.println("*  Welcome to the ATM Project\t   *");
				System.out.println("*\n************************************");
				
				System.out.print("Are you a Returning Customer or New? ");
				customer = cutomerNewOld.next().toUpperCase();
				
				If (customer.equals("NEW") || customer.equals("RETURNING")){
					
				}
				
				System.out.print("\nEnter Your Customer Number: ");
				setCustomerNumber(menuInput.nextInt());
				
				System.out.print("Enter Your PinNumber: ");
				setPinNumber(menuInput.nextInt());
				} catch (Exception e) {
					System.out.println("\nInvalid character(s). Only numbers.\n" );
					getLogin();
					x = 2;
					}
			
			for (Entry<Integer, Integer> entry : data.entrySet()){
				if (entry.getKey() == getCustomerNumber() && entry.getValue() == getPinNumber());
				getAccountType();
				}
			System.out.println("Wrong");
			}while (x==1);
		}
	
	/*Displays New user account creation*/
	public void getNewUser() throws IOException{
		int newCustomerNum, newPinNum;
		
		System.out.print("\nCreate Your Customer Number: ");
		newCustomerNum = userChoiceInput.nextInt();
		
		System.out.print("Create Your Pin Number: ");
		newPinNum = userChoiceInput.nextInt();
		}
	
	/*Display Account Type Menu with Selection*/
	private void getAccountType() {
		// TODO Auto-generated method stub
		System.out.println("\nSelect the Account you want to access: ");
		System.out.println("Type 1 - Checking Account ");
		System.out.println("Type 2 - Saving ACcount ");
		System.out.println("Type 3 - Exit ");
		System.out.print("Choice: ");
		
		selection = menuInput.nextInt();
		
		switch(selection) {
		case 1:
			getChecking();
			break;
		case 2:
			getSavings();
			break;
		case 3:
			System.out.print("Thank you for using this ATM bye\n");
			break;
		default:
			System.out.println("\nInvalide Chioce\n");
			getAccountType();
			}
		}
	
	/*Display Checking Account Menu with selections*/
	private void getChecking() {
		System.out.println("\nChecking Account: ");
		System.out.println("Type 1 - View Balance ");
		System.out.println("Type 2 - Withdraw Funds ");
		System.out.println("Type 3 - Deposit Funds ");
		System.out.println("Type 4 - Exit ");
		System.out.print("Choice: ");
		
		selection = menuInput.nextInt();
		
		switch(selection) {
		case 1:
			System.out.println("Checking Account Balance: " + moneyFormat.format(getCheckingBalance()));
			getAccountType();
			break;
		case 2:
			getCheckingWithdrawInput();
			getAccountType();
			break;
		case 3:
			getCheckingDepositInput();
			getAccountType();
			break;
		case 4:
			System.out.print("Thank you for using this ATM");
			break;	
		default:
			System.out.println("\nInvalide Chioce\n");
			getChecking();
			}
		}
	
	private void getSavings() {
		System.out.println("\nSavings Account: ");
		System.out.println("Type 1 - View Balance ");
		System.out.println("Type 2 - Withdraw Funds ");
		System.out.println("Type 3 - Deposit Funds ");
		System.out.println("Type 4 - Exit ");
		System.out.print("Choice: ");
		
		selection = menuInput.nextInt();
		
		switch(selection) {
		case 1:
			System.out.println("Checking Account Balance: " + moneyFormat.format(getSavingsBalance()));
			getAccountType();
			break;
		case 2:
			getSavingsWithdrawInput();
			getAccountType();
			break;
		case 3:
			getSavingsDepositInput();
			getAccountType();
			break;
		case 4:
			System.out.print("Thank you for using this ATM");
			break;
		default:
			System.out.println("\nInvalide Chioce\n");
			getSavings();
			}
		}
	}
