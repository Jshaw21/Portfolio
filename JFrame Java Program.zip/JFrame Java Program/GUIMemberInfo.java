import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.nio.file.*;
import static java.nio.file.StandardOpenOption.*;
import javax.swing.*;

//GUIMemberInfo.java
//Jemuel Shaw
//Date: 4/9/2018
public class GUIMemberInfo extends JFrame implements ActionListener{
	//Creates label components
	JLabel labelID = new JLabel("Member ID");
	JLabel labelName = new JLabel("Member Name");          
	JLabel labelAddress = new JLabel("Member Address");
	JLabel labelAge = new JLabel("Age");
	JLabel message = new JLabel("Enter Member Info");
	
	//Creates text box components
	JTextField textboxID = new JTextField("\t");
	JTextField textboxName = new JTextField("\t");          
	JTextField textboxAddress = new JTextField("\t");
	JTextField textboxAge = new JTextField("\t");
	
	//Creates button components
	JButton file = new JButton("Output to File");
	public GUIMemberInfo() {
		//call super
		super("Member Info");
		
		//form settings
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		FlowLayout flowLayout = new FlowLayout();
		
		//declare font object
		Font font = new Font("Times New Roman", Font.ITALIC, 14);
		
		//set label fonts
		
		labelID.setFont(font);
		labelName.setFont(font);
		labelAddress.setFont(font);
		labelAge.setFont(font);
		
		message.setFont(new Font("Times New Roman", Font.ITALIC, 50));
		message.setForeground(Color.CYAN);
		
		//set label color
		labelID.setForeground(Color.cyan);
		labelName.setForeground(Color.cyan);
		labelAddress.setForeground(Color.cyan);
		labelAge.setForeground(Color.cyan);
		
		//set frame background color
		getContentPane().setBackground(Color.black);
		
		//add components to JFrame
		setLayout(flowLayout);
		add(message);
		add(labelID);
		add(textboxID);
		add(labelName);
		add(textboxName);
		add(labelAddress);
		add(textboxAddress);
		add(labelAge);
		add(textboxAge);
		add(file);
		
		//add a tool tip
		file.setToolTipText("Click to output to file"); //p752
		
		//register the action listener 
		file.addActionListener(this);
		textboxID.addActionListener(this);
		textboxName.addActionListener(this);
		textboxAddress.addActionListener(this);
		textboxAge.addActionListener(this);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//constant variables
		final int FRAME_WIDTH = 430;
		final int FRAME_HIEGHT = 500;
		
		//instantiate frame object
		GUIMemberInfo frame = new GUIMemberInfo();
		
		//set attributes
		frame.setSize(FRAME_WIDTH, FRAME_HIEGHT);
		frame.setBounds(430, 500, FRAME_WIDTH, FRAME_HIEGHT);
		frame.setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		String memberID = textboxID.getText();
		String memberName = textboxName.getText();
		String memberAddress = textboxAddress.getText();
		String memberAge = textboxAge.getText();
		
		//find the path of the current folder location and creates an object
		String filename = "MemberInfo.txt";
		Path currentPath = Paths.get(filename);
		Path fullpathFile = currentPath.toAbsolutePath();
		
		String dataLine = "";//variable for outputting to the file
		String delimiterID = "Member ID:";
		String delimiterName = "Member Name:";
		String delimiterAddress = "Member Address:";
		String delimiterAge = "Age:";
		
		//get data to write to the file
		try {
			//creates a buffered OutputStream object - takes the path object as an argument
			OutputStream output = new BufferedOutputStream(Files.newOutputStream(fullpathFile, CREATE, APPEND));
			
			//creates a Buffered writer object - take an output stream object as an argument
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(output));
			
			//string of data to write to the file
			dataLine = delimiterID + memberID + delimiterName + memberName + delimiterAddress + memberAddress + delimiterAge + memberAge;
			
			//writes data to the file
			writer.write(dataLine, 0, dataLine.length()); //writes data for the length of the string
			writer.newLine(); //creates new Line
			writer.close();//close output stream writer
			
			JOptionPane.showMessageDialog(null, "Output Success");
		//end try
		}catch(Exception ex) {
			JOptionPane.showMessageDialog(null, "There was an error");
		}//end catch
		
		textboxID.setText("");
		textboxName.setText("");
		textboxAddress.setText("");
		textboxAge.setText("");
	}
}
