import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class GUIPlanCost extends JFrame implements ActionListener{
	//Creates label components
		JLabel fitness = new JLabel("Fitness Cost");
		JLabel total = new JLabel("                                 Total Cost");
		JLabel totalCost = new JLabel("$0");
		
		//Creates check box components
		JRadioButton gym = new JRadioButton("GYM- $50.00");
		JRadioButton swim = new JRadioButton("SWIM- $50.00");          
		JRadioButton combo = new JRadioButton("COMBO- $90.00");
		JCheckBox nutritionalPlan = new JCheckBox("NUTRITIONAL PLAN- $10.00");
		
		//create button group components
		ButtonGroup aGroup = new ButtonGroup();
		
		public GUIPlanCost() {
			//call super
			super("Fitness Cost");
			
			//form settings
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			FlowLayout flowLayout = new FlowLayout();
			
			//set fitness label font
			fitness.setFont(new Font("Times New Roman", Font.BOLD, 50));
			fitness.setForeground(Color.cyan);
			
			gym.setBackground(Color.CYAN);
			swim.setBackground(Color.CYAN);
			combo.setBackground(Color.CYAN);
			nutritionalPlan.setBackground(Color.CYAN);
			
			total.setForeground(Color.yellow);
			totalCost.setForeground(Color.yellow);
			
			//set frame background color
			getContentPane().setBackground(Color.BLACK);
			
			aGroup.add(gym);
			aGroup.add(swim);
			aGroup.add(combo);
			
			//add components to JFrame
			setLayout(flowLayout);
			add(fitness);
			add(gym);
			add(swim);
			add(combo);
			add(nutritionalPlan);
			add(total);
			add(totalCost);
			
			//register the action listener 
			gym.addActionListener(this);
			swim.addActionListener(this);
			combo.addActionListener(this);
			nutritionalPlan.addActionListener(this);
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//constant variables
		final int FRAME_WIDTH = 360;
		final int FRAME_HIEGHT = 450;
		
		//instantiate frame object
		GUIPlanCost frame = new GUIPlanCost();
		
		//set attributes
		frame.setSize(FRAME_WIDTH, FRAME_HIEGHT);
		frame.setBounds(500, 600, FRAME_WIDTH, FRAME_HIEGHT);
		frame.setVisible(true);
		frame.setBackground(Color.black);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		Object source = e.getSource();
		
		int total = 0;
		
		if(gym.isSelected()) {
			total += 50;
			}else if(swim.isSelected()) {
				total += 50;
				}else if(combo.isSelected()) {
					total += 90;
					}
		
		if(nutritionalPlan.isSelected()) {
			total += 10;
			}
		
		String result = Integer.toString(total);
		
		//display result
		totalCost.setText("$" + result);
	}

}
