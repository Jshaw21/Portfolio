import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.geom.*;
public class MemberMenuJFrame extends JFrame implements ActionListener, MouseListener, MouseMotionListener{
	//Create Menu Components
	JMenuBar mainBar = new JMenuBar();
	JMenu memberMenu = new JMenu("Members");
	JMenuItem numMemberMenu = new JMenuItem("Enter Members");
	JMenuItem memberSign = new JMenuItem("Member Sign");
	JMenu costMenu = new JMenu("Costs");
	JMenuItem calMenu = new JMenuItem("Calculate Cost");
	
	JLabel label = new JLabel("Use menu bar above to make a selection");
	
	//declaring variables
	int xStart, yStart;
	int xStop, yStop;
	BasicStroke aStroke = new BasicStroke(5.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND);
	
	public MemberMenuJFrame() {
		//call super
		super("Menu");
		
		//form settings
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//add components to JFrame
		setLayout(new FlowLayout());
		setJMenuBar(mainBar);
		mainBar.add(memberMenu);
		mainBar.add(costMenu);
		memberMenu.add(numMemberMenu);
		memberMenu.add(memberSign);
		costMenu.add(calMenu);
		add(label);
		
		//set label font and color
		label.setFont(new Font("Times New Roman", Font.BOLD, 14));
		label.setForeground(Color.CYAN);
		
		//set frame background color
		getContentPane().setBackground(Color.black);
		
		//register the action listener 
		numMemberMenu.addActionListener(this);
		memberSign.addActionListener(this);
		calMenu.addActionListener(this);
		
		//register mouse listener
		addMouseListener(this);
		addMouseMotionListener(this);
	}
	
	public void paintComponent(Graphics g) {
		Graphics2D gr2D = (Graphics2D)g;
		Line2D.Float line = new Line2D.Float((float)xStart, (float)yStart, (float)xStop, (float)yStop);
		gr2D.setStroke(aStroke);
		gr2D.draw(line);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//constant variables
		final int FRAME_WIDTH = 300;
		final int FRAME_HIEGHT = 400;
		
		//instantiate frame object
		MemberMenuJFrame frame = new MemberMenuJFrame();
		GUIMemberInfo member = new GUIMemberInfo();
		GUIPlanCost plan = new GUIPlanCost();
		
		//set attributes
		frame.setSize(FRAME_WIDTH, FRAME_HIEGHT);
		frame.setBounds(300, 400, FRAME_WIDTH, FRAME_HIEGHT);
		frame.setVisible(true);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if(source == numMemberMenu) {
			GUIMemberInfo memberInfo = new GUIMemberInfo();
			memberInfo.setVisible(true);
			memberInfo.setSize(430, 500);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		} 
		
		if (source == memberSign) {
			final int FRAME_WIDTH = 400;
			final int FRAME_HIEGHT = 400;
			
			//instantiate frame object
			JFrame signature = new JFrame();
			
			//set attributes
			signature.add(new Signature());
			signature.setSize(FRAME_WIDTH, FRAME_HIEGHT);
			signature.setBounds(300, 300, FRAME_WIDTH, FRAME_HIEGHT);
			signature.setVisible(true);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
		
		if(source == calMenu) {
			GUIPlanCost memberPlan = new GUIPlanCost();
			memberPlan.setVisible(true);
			memberPlan.setSize(360, 450);
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		}
	}
	
	@Override
	public void mousePressed(MouseEvent e) {
		//TODO Auto-generated method stub
		xStart = e.getX();
		yStart = e.getY();
	}
	
	@Override
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		xStop = e.getX();
		yStop = e.getY();
		repaint();
		xStart = xStop;
		yStart = yStop;
	}
	
	@Override
	public void mouseMoved(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
}