
public class Sort3 {
	/**
	* Sorts an array of integer from low to high
	* pre: none
	* post: Integers have been sorted from low to high
	*/
	public static void insertionSort(int[] items) {
		int temp, previousIndex;
		for (int index = 1; index < items.length; index++) {
			temp = items[index];
			previousIndex = index - 1;
			while ((items[previousIndex] > temp) && (previousIndex > 0)) {
				items[previousIndex + 1] = items[previousIndex];
				previousIndex -= 1; //decrease index to compare current
				} //item with next previous item
			if (items[previousIndex] > temp) {
				/* shift item in first element up into next element */
				items[previousIndex + 1] = items[previousIndex];
				/* place current item at index 0 (first element) */
				items[previousIndex] = temp;
				} else {
					/* place current item at index ahead of previous item */
					items[previousIndex + 1] = temp;
					}
			}
		}
	}
